<div style="display: flex; align-items: center;">
  <img src="Logo/icon_bg.png" alt="Pluse logo" style="width: 64px; height: 64px; margin-right: 10px;" />
  <h1>Pluse - The Fitness Community Hub</h1>
</div>
<p>Pluse is a cutting-edge social media platform designed exclusively for fitness enthusiasts. Our aim is to connect individuals who share a passion for health and fitness, allowing them to inspire and motivate each other through their journeys. Pluse is where workouts, nutrition, and personal milestones come to life through social sharing.</p>
