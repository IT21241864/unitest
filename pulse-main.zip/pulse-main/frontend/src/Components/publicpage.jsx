import React from 'react';

export const PublicPage = () => {
    return (
        <div>
            Public page
        </div>
    );
};