import React from 'react';

export const PrivatePage = () => {
    return (
        <div>
            Public page
        </div>
    );
};