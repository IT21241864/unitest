package me.pluse.mealplanservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MealplanServiceApplication {
    public static void main(String[] args){
        SpringApplication.run(MealplanServiceApplication.class, args);
    }
}
