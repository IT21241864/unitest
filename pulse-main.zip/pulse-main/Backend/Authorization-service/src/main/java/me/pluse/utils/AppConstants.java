package me.pluse.utils;

public class AppConstants {

    public static int bCryptEncoderStrength = 10;

    public static String USERID_PREFIX = "C0ID";
    public static String USERID_FORMATTOR_PARAM = "%05d";
}
