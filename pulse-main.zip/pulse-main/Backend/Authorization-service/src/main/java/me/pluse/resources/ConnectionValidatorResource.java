package me.pluse.resources;

public class ConnectionValidatorResource {
}
