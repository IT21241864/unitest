package me.pluse.security;

public enum UserPermission {

        READ_ONLY,
        WRITE_ONLY,
        USER,
        READ_ONLY_ADMIN,
        ADMIN;

}
