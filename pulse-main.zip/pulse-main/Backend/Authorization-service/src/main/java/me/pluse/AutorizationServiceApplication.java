package me.pluse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutorizationServiceApplication {
    public static void main(String[] args){
        SpringApplication.run(AutorizationServiceApplication.class, args);
    }
}
